@extends('layouts.app')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-12 card">
                <div class="card-body">
                    <h2 class="card-title">Welkom bij PopIt-Tag!</h2>
                    <p class="card-text">Om je socials toe te voegen, login op je account of maak een nieuw account aan.</p>
                </div>
            </div>
        </div>
    </div>
@endsection
